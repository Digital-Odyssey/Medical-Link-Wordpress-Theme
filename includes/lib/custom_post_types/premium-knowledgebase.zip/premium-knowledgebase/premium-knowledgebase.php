<?php 

/*
Plugin Name: Premium Knowledge Base for Medical-Link theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a knowledge base post type displaying knowledge base items.
Version: 1.2
Author: Micro Themes
Author URI: http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'pm_ln_create_knowledgebase');
add_action('init', 'pm_ln_knowledgebase_categories');
add_action('init', 'pm_ln_knowledgebase_tags');
add_action('admin_init', 'pm_ln_knowledgebase_admin');
add_action('save_post', 'pm_ln_add_knowledgebase_fields', 10, 2);
add_action('admin_menu', 'pm_ln_add_knowledgebase_settings' );// ADD SETTINGS PAGE

//Translation support
add_action('plugins_loaded', 'pm_ln_load_knowledgebase_textdomain');

function pm_ln_load_knowledgebase_textdomain() { 
	load_plugin_textdomain( 'knowledgeBaseplugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function pm_ln_create_knowledgebase() {
	
	$pm_knowledgebase_slug = get_option('pm_knowledgebase_slug');
	$slug = '';
	
	if( $pm_knowledgebase_slug !== '' ) {
		$slug = $pm_knowledgebase_slug;
	} else {
		$slug = 'knowledge-center';
	}
	
	register_post_type('post_knowledgebase',
		array(
			'labels' => array(
				'name' => esc_attr__( 'Knowledge Base', 'knowledgeBaseplugin' ),
				'singular_name' => esc_attr__( 'Knowledge Base', 'knowledgeBaseplugin' ),
				'add_new' => esc_attr__( 'Add New Knowledge Base post', 'knowledgeBaseplugin' ),
				'add_new_item' => esc_attr__( 'Add New Knowledge Base post', 'knowledgeBaseplugin' ),
				'edit' => esc_attr__( 'Edit', 'knowledgeBaseplugin' ),
				'edit_item' => esc_attr__( 'Edit Knowledge Base post', 'knowledgeBaseplugin' ),
				'new_item' => esc_attr__( 'New Knowledge Base post', 'knowledgeBaseplugin' ),
				'view' => esc_attr__( 'View', 'knowledgeBaseplugin' ),
				'view_item' => esc_attr__( 'View Knowledge Base post', 'knowledgeBaseplugin' ),
				'search_items' => esc_attr__( 'Search Knowledge Base posts', 'knowledgeBaseplugin' ),
				'not_found' => esc_attr__( 'No Knowledge Base posts found', 'knowledgeBaseplugin' ),
				'not_found_in_trash' => esc_attr__( 'No Knowledge Base posts found in Trash', 'knowledgeBaseplugin' ),
				'parent' => esc_attr__( 'Parent Knowledge Base post', 'knowledgeBaseplugin' )
			),
			'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => esc_attr__( 'Easily lets you add new Knowledge Base posts', 'knowledgeBaseplugin' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => $slug),
			//'taxonomies' => array('category', 'post_tag')

		)
	); 
}

function pm_ln_knowledgebase_categories() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => esc_attr__( 'Knowledge Base Categories', 'knowledgeBaseplugin' ),
		'singular_name' => esc_attr__( 'Knowledge Base Categories', 'knowledgeBaseplugin' ),
		'search_items' =>  esc_attr__( 'Search Knowledge Base Categories', 'knowledgeBaseplugin' ),
		'popular_items' => esc_attr__( 'Popular Knowledge Base Categories', 'knowledgeBaseplugin' ),
		'all_items' => esc_attr__( 'All Knowledge Base Categories', 'knowledgeBaseplugin' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => esc_attr__( 'Edit Knowledge Base Category', 'knowledgeBaseplugin' ),
		'update_item' => esc_attr__( 'Update Knowledge Base Category', 'knowledgeBaseplugin' ),
		'add_new_item' => esc_attr__( 'Add Knowledge Base Category', 'knowledgeBaseplugin' ),
		'new_item_name' => esc_attr__( 'New Knowledge Base Category Name', 'knowledgeBaseplugin' ),
		'separate_items_with_commas' => esc_attr__( 'Separate Knowledge Base Categories with commas', 'knowledgeBaseplugin' ),
		'add_or_remove_items' => esc_attr__( 'Add or remove Knowledge Base Categories', 'knowledgeBaseplugin' ),
		'choose_from_most_used' => esc_attr__( 'Choose from the most used Knowledge Base Categories', 'knowledgeBaseplugin' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'knowledgebasecats', 'post_knowledgebase', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'knowledge-base-category' ), // changes name in permalink structure
    ));
	
}


function  pm_ln_knowledgebase_tags() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => esc_attr__( 'Knowledge Base Tags', 'knowledgeBaseplugin' ),
		'singular_name' => esc_attr__( 'Knowledge Base Tags', 'knowledgeBaseplugin' ),
		'search_items' =>  esc_attr__( 'Search Knowledge Base Tags', 'knowledgeBaseplugin' ),
		'popular_items' => esc_attr__( 'Popular Knowledge Base Tags', 'knowledgeBaseplugin' ),
		'all_items' => esc_attr__( 'All Knowledge Base Tags', 'knowledgeBaseplugin' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => esc_attr__( 'Edit Knowledge Base Tag', 'knowledgeBaseplugin' ),
		'update_item' => esc_attr__( 'Update Knowledge Base Tag', 'knowledgeBaseplugin' ),
		'add_new_item' => esc_attr__( 'Add Knowledge Base Tag', 'knowledgeBaseplugin' ),
		'new_item_name' => esc_attr__( 'New Knowledge Base Tag Name', 'knowledgeBaseplugin' ),
		'separate_items_with_commas' => esc_attr__( 'Separate Knowledge Base Tags with commas', 'knowledgeBaseplugin' ),
		'add_or_remove_items' => esc_attr__( 'Add or remove Knowledge Base Tags', 'knowledgeBaseplugin' ),
		'choose_from_most_used' => esc_attr__( 'Choose from the most used Knowledge Base Tags', 'knowledgeBaseplugin' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'knowledgebasetags', 'post_knowledgebase', array(
		'hierarchical' => false, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'knowledge-base-tag' ), // changes name in permalink structure
    ));
	
}

//Add sub menus
function pm_ln_add_knowledgebase_settings() {

	//create custom top-level menu
	//add_menu_page( 'Pulsar Framework Documentation', 'Theme Documentation', 'manage_options', __FILE__, 'pm_documentation_main_page',	plugins_url( '/images/wp-icon.png', __FILE__ ) );
	
	//create sub-menu items
	add_submenu_page( 'edit.php?post_type=post_knowledgebase', esc_attr__('Knowledge Base Settings', 'pulsarmedia'),  esc_attr__('Knowledge Base Settings', 'pulsarmedia'), 'manage_options', 'knowledgebase_settings',  'pm_ln_knowledgebase_settings_page' );
	
	//create an options page under Settings tab
	//add_options_page('My API Plugin', 'My API Plugin', 'manage_options', 'pm_myplugin', 'pm_myplugin_option_page');	
}


//Settings page
function pm_ln_knowledgebase_settings_page() {
		
	//Save data first
	if (isset($_POST['pm_knowledgebase_settings_update'])) {
		
		update_option('pm_knowledgebase_slug', (string)$_POST["pm_knowledgebase_slug"]);
		
		echo '<div id="message" class="updated fade"><h4>'.esc_attr__('Your settings have been saved.', 'pulsarmedia').'</h4></div>';
		
	}//end of save data
	
	$pm_knowledgebase_slug = get_option('pm_knowledgebase_slug');

	
	?>
	
	<div class="wrap">
		<?php screen_icon(); ?>
		<h2><?php esc_attr_e('Services Settings', 'pulsarmedia') ?></h2>
		
		<h4><?php esc_attr_e('Configure the settings for the Knowledge Base plug-in below:', 'pulsarmedia') ?></h4>
		
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		
			<input type="hidden" name="pm_knowledgebase_settings_update" id="pm_knowledgebase_settings_update" value="true" />
								
			<label for="pm_knowledgebase_slug"><?php esc_attr_e('Slug name', 'pulsarmedia') ?></label>
			<input type="text" id="pm_knowledgebase_slug" name="pm_knowledgebase_slug" value="<?php echo $pm_knowledgebase_slug; ?>">
			
            <p><?php esc_attr_e('<strong>NOTE:</strong> You will have to reset your permalinks after making changes to the slug name in order to avoid 404 error pages.', 'pulsarmedia') ?></p>
            
			<br /><br />
            
			<div class="pm-payel-submit">
				<input type="submit" name="pm_settings_update" class="button button-primary button-large" value="<?php esc_attr_e('Update Settings', 'pulsarmedia'); ?> &raquo;" />
			</div>
		
		</form>
		
	</div>
	
	<?php
	
}


function pm_ln_knowledgebase_admin() {
		
	
	add_meta_box(
		'pm_glossary_index',
		esc_attr__('Glossary Index', 'knowledgeBaseplugin' ),
		'pm_ln_glossary_index_list',
		'post_knowledgebase',
		'side'
		//'low'
	);
	
	add_meta_box( 
		'pm_knowledge_base_post_layout_meta', //ID
		esc_attr__('Sidebar Layout', 'knowledgeBaseplugin' ),  //label
		'pm_knowledge_base_post_layout_meta_function' , //function
		'post_knowledgebase', 
		'side' 
	);
	
	add_meta_box(
        'custom_knowledgebase_sidebar',
        esc_attr__('Custom Sidebar', 'knowledgeBaseplugin'),
        'pm_ln_knowledgebase_sidebar_function',
        'post_knowledgebase',
        'side'
    );
	
	add_meta_box( 
		'pm_disable_share_feature', //ID
		esc_attr__('Disable Print and Share features?', 'knowledgeBaseplugin' ),  //label
		'pm_disable_knowledge_share_feature_function' , //function
		'post_knowledgebase', //Post type
		'side'
	);
	
}


function pm_knowledge_base_post_layout_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_knowledge_base_post_layout_meta = get_post_meta( $post->ID, 'pm_knowledge_base_post_layout_meta', true );
	
	?>
        <p><?php esc_attr_e('Select your desired layout for this post.', 'knowledgeBaseplugin'); ?></p>
        <select id="pm_knowledge_base_post_layout_meta" name="pm_knowledge_base_post_layout_meta" class="pm-admin-select-list">  
            <option value="no-sidebar" <?php selected( $pm_knowledge_base_post_layout_meta, 'no-sidebar' ); ?>><?php esc_attr_e('No Sidebar', 'knowledgeBaseplugin') ?></option>
            <option value="left-sidebar" <?php selected( $pm_knowledge_base_post_layout_meta, 'left-sidebar' ); ?>><?php esc_attr_e('Left Sidebar', 'knowledgeBaseplugin') ?></option>
            <option value="right-sidebar" <?php selected( $pm_knowledge_base_post_layout_meta, 'right-sidebar' ); ?>><?php esc_attr_e('Right Sidebar', 'knowledgeBaseplugin') ?></option>
        </select>
        
        
    
    <?php
	
	
}

function pm_ln_glossary_index_list( $post ){
	
    $letters = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
     
    $custom = get_post_custom($post->ID);
     
    if(isset($custom['glossary_index']))
        $val = $custom['glossary_index'][0];
    else
        $val = "default";
 
    // Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );
 
    // The actual fields for data entry
    $output = '<p><label for="myplugin_new_field">'.esc_attr__("Assign this post to the appropiate glossary index.", 'knowledgeBaseplugin' ).'</label></p>';
    $output .= '<select name="glossary_index">';
 
    // Add a default option
    $output .= "<option";
    if($val == "a")
        $output .= " selected='selected'";
    $output .= ' value="default">'.esc_attr__( 'Choose a Letter', 'knowledgeBaseplugin' ).'</option>';
     
    // Fill the select element with the alphabet
    foreach($letters as $letter)
    {
        $output .= "<option";
        if($letter == $val)
            $output .= " selected='selected'";
        $output .= " value='".$letter."'>".strtoupper($letter)."</option>";
    }
   
    $output .= "</select>";
     
    echo $output;
}

function pm_disable_knowledge_share_feature_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_disable_share_feature = get_post_meta( $post->ID, 'pm_disable_share_feature', true );
	
	?>
        <select id="pm_disable_share_feature" name="pm_disable_share_feature" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_disable_share_feature, 'no' ); ?>><?php esc_attr_e('No', 'knowledgeBaseplugin') ?></option>
            <option value="yes" <?php selected( $pm_disable_share_feature, 'yes' ); ?>><?php esc_attr_e('Yes', 'knowledgeBaseplugin') ?></option>
        </select>
            
    <?php
	
}


function pm_ln_knowledgebase_sidebar_function( $post ){
	
    global $wp_registered_sidebars;
     
    $custom = get_post_custom($post->ID);
     
    if(isset($custom['custom_knowledgebase_sidebar']))
        $val = $custom['custom_knowledgebase_sidebar'][0];
    else
        $val = "default";
 
    // Use nonce for verification
     wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );
 
    // The actual fields for data entry
    $output = '<p><label for="myplugin_new_field">'.esc_attr__("Choose a sidebar to display", 'twentyeleven' ).'</label></p>';
    $output .= "<select name='custom_knowledgebase_sidebar'>";
 
    // Add a default option
    $output .= "<option";
    if($val == "default")
        $output .= " selected='selected'";
    $output .= " value='default'>".esc_attr__('No Sidebar', 'knowledgeBaseplugin')."</option>";
     
    // Fill the select element with all registered sidebars
    foreach($wp_registered_sidebars as $sidebar_id => $sidebar)
    {
        $output .= "<option";
        if($sidebar['name'] == $val)
            $output .= " selected='selected'";
        $output .= " value='".$sidebar['name']."'>".$sidebar['name']."</option>";
    }
   
    $output .= "</select>";
     
    echo $output;
}



function pm_ln_add_knowledgebase_fields( $post_id, $post_knowledgebase ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_knowledgebase->post_type == 'post_knowledgebase' ) {
			
			// Store data in post meta table if present in post data			
			if(isset($_POST['pm_disable_share_feature']) ){
				update_post_meta($post_id, "pm_disable_share_feature", $_POST['pm_disable_share_feature']);
			}			
			
			if(isset($_POST['glossary_index']) ){
				update_post_meta($post_id, "glossary_index", $_POST['glossary_index']);
			}
			
			if(isset($_POST['pm_knowledge_base_post_layout_meta']) ){
				update_post_meta($post_id, "pm_knowledge_base_post_layout_meta", $_POST['pm_knowledge_base_post_layout_meta']);
			}
			
			if(isset($_POST['custom_knowledgebase_sidebar'])){
				update_post_meta($post_id, "custom_knowledgebase_sidebar", $_POST['custom_knowledgebase_sidebar']);
			}
			
				
		}
	
	endif;	
}

?>
<?php 

/*
Plugin Name: Staff Members Post Type for Medical-Link Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type displaying staff member profiles.
Version: 1.2
Author: Micro Themes
Author URI:http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'pm_ln_create_staff_member');
add_action('init', 'pm_ln_staff_titles');
add_action('admin_init', 'pm_ln_staff_admin');
add_action('save_post', 'pm_ln_add_staff_member_fields', 10, 2);
add_action('admin_menu', 'pm_ln_add_staff_settings' );// ADD SETTINGS PAGE

//Translation support
add_action('plugins_loaded', 'pm_ln_load_staff_textdomain');

function pm_ln_load_staff_textdomain() { 
	load_plugin_textdomain( 'staffPlugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function pm_ln_create_staff_member() {
	
	$pm_staff_members_slug = get_option('pm_staff_members_slug');
	$slug = '';
	
	if( $pm_staff_members_slug !== '' ) {
		$slug = $pm_staff_members_slug;
	} else {
		$slug = 'staff-member';
	}
	
    register_post_type( 'post_staff',
        array(
            'labels' => array(
				'name' => esc_attr__( 'Staff', 'staffPlugin' ),
				'singular_name' => esc_attr__( 'Staff', 'staffPlugin' ),
				'add_new' => esc_attr__( 'Add New Staff profile', 'staffPlugin' ),
				'add_new_item' => esc_attr__( 'Add New Staff profile', 'staffPlugin' ),
				'edit' => esc_attr__( 'Edit', 'staffPlugin' ),
				'edit_item' => esc_attr__( 'Edit Staff profile', 'staffPlugin' ),
				'new_item' => esc_attr__( 'New Staff profile', 'staffPlugin' ),
				'view' => esc_attr__( 'View', 'staffPlugin' ),
				'view_item' => esc_attr__( 'View Staff profile', 'staffPlugin' ),
				'search_items' => esc_attr__( 'Search Staff profiles', 'staffPlugin' ),
				'not_found' => esc_attr__( 'No Staff profiles found', 'staffPlugin' ),
				'not_found_in_trash' => esc_attr__( 'No Staff profiles found in Trash', 'staffPlugin' ),
				'parent' => esc_attr__( 'Parent Staff', 'staffPlugin' )
			),
            'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => esc_attr__( 'Easily lets you add new staff profiles', 'staffPlugin' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => $slug),
			//'taxonomies' => array('category', 'post_tag')
			
        )
    );
	
}

function pm_ln_staff_titles() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => esc_attr__( 'Staff Titles', 'staffPlugin' ),
		'singular_name' => esc_attr__( 'Staff Titles', 'staffPlugin' ),
		'search_items' =>  esc_attr__( 'Search Staff Titles', 'staffPlugin' ),
		'popular_items' => esc_attr__( 'Popular Staff Titles', 'staffPlugin' ),
		'all_items' => esc_attr__( 'All Staff Titles', 'staffPlugin' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => esc_attr__( 'Edit Staff Title', 'staffPlugin' ),
		'update_item' => esc_attr__( 'Update Staff Title', 'staffPlugin' ),
		'add_new_item' => esc_attr__( 'Add Staff Title', 'staffPlugin' ),
		'new_item_name' => esc_attr__( 'New Staff Title', 'staffPlugin' ),
		'separate_items_with_commas' => esc_attr__( 'Separate Staff Titles with commas', 'staffPlugin' ),
		'add_or_remove_items' => esc_attr__( 'Add or remove Staff Title', 'staffPlugin' ),
		'choose_from_most_used' => esc_attr__( 'Choose from the most used Staff Titles', 'staffPlugin' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'staff_cats', 'post_staff', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'staff-category' ), // changes name in permalink structure
    ));
	
	//flush_rewrite_rules();	
}

//Add sub menus
function pm_ln_add_staff_settings() {

	//create custom top-level menu
	//add_menu_page( 'Pulsar Framework Documentation', 'Theme Documentation', 'manage_options', __FILE__, 'pm_documentation_main_page',	plugins_url( '/images/wp-icon.png', __FILE__ ) );
	
	//create sub-menu items
	add_submenu_page( 'edit.php?post_type=post_staff', esc_attr__('Staff Settings', 'staffPlugin'),  esc_attr__('Staff Settings', 'staffPlugin'), 'manage_options', 'staff_settings',  'pm_ln_staff_settings_page' );
	
	//create an options page under Settings tab
	//add_options_page('My API Plugin', 'My API Plugin', 'manage_options', 'pm_myplugin', 'pm_myplugin_option_page');	
}


//Settings page
function pm_ln_staff_settings_page() {
		
	//Save data first
	if (isset($_POST['pm_staff_settings_update'])) {
		
		update_option('pm_staff_members_slug', (string)$_POST["pm_staff_members_slug"]);
		update_option('pm_staff_post_view_btn_text', (string)$_POST["pm_staff_post_view_btn_text"]);		
		
		echo '<div id="message" class="updated fade"><h4>'.esc_attr__('Your settings have been saved.', 'staffPlugin').'</h4></div>';
		
	}//end of save data
	
	$pm_staff_members_slug = get_option('pm_staff_members_slug');
	$pm_staff_post_view_btn_text = get_option('pm_staff_post_view_btn_text');
	
	?>
	
	<div class="wrap">
		<?php screen_icon(); ?>
		<h2><?php esc_attr_e('Staff Member Settings', 'staffPlugin') ?></h2>
		
		<h4><?php esc_attr_e('Configure the settings for the Staff Members plug-in below:', 'staffPlugin') ?></h4>
		
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		
			<input type="hidden" name="pm_staff_settings_update" id="pm_staff_settings_update" value="true" />
								
			<label for="pm_staff_members_slug"><?php esc_attr_e('Slug name', 'staffPlugin') ?></label>
			<input type="text" id="pm_staff_members_slug" name="pm_staff_members_slug" value="<?php echo esc_attr($pm_staff_members_slug); ?>">
			
            <p><?php esc_attr_e('NOTE: You will have to reset your permalinks after making changes to the slug name in order to avoid 404 error pages.', 'staffPlugin') ?></p>
                        
            <label for="pm_staff_post_view_btn_text"><?php esc_attr_e('Staff Post View Button Text', 'staffPlugin') ?></label>
			<input type="text" id="pm_staff_post_view_btn_text" name="pm_staff_post_view_btn_text" value="<?php echo esc_attr($pm_staff_post_view_btn_text); ?>">
            
            <br /><br />
            
			<div class="pm-payel-submit">
				<input type="submit" name="pm_settings_update" class="button button-primary button-large" value="<?php esc_attr_e('Update Settings', 'staffPlugin'); ?> &raquo;" />
			</div>
		
		</form>
		
	</div>
	
	<?php
	
}

function pm_ln_staff_admin() {
	
    //Header Image
	add_meta_box( 
		'pm_staff_image_meta', //ID
		'Staff Profile Image',  //label
		'pm_staff_image_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Staff Title
	add_meta_box( 
		'pm_staff_title_meta', //ID
		'Staff Title',  //label
		'pm_staff_title_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Staff Title
	add_meta_box( 
		'pm_staff_quote_meta', //ID
		'Personal Quote',  //label
		'pm_staff_quote_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Twitter Address
	add_meta_box( 
		'pm_staff_twitter_meta', //ID
		'Twitter Address',  //label
		'pm_staff_twitter_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Facebook Address
	add_meta_box( 
		'pm_staff_facebook_meta', //ID
		'Facebook Address',  //label
		'pm_staff_facebook_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Google Plus Address
	add_meta_box( 
		'pm_staff_gplus_meta', //ID
		'Google Plus Address',  //label
		'pm_staff_gplus_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Linkedin Address
	add_meta_box( 
		'pm_staff_linkedin_meta', //ID
		'Linkedin Address',  //label
		'pm_staff_linkedin_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Email Address
	add_meta_box( 
		'pm_staff_email_address_meta', //ID
		'Email Address',  //label
		'pm_staff_email_address_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Disable Share options
	add_meta_box( 
		'pm_disable_share_feature', //ID
		'Disable Share feature?',  //label
		'pm_disable_share_function' , //function
		'post_staff', //Post type
		'side'
	);
	
}


function pm_staff_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_image_meta = get_post_meta( $post->ID, 'pm_staff_image_meta', true );
		

	//HTML code
	?>
    	<p><?php esc_attr_e('Recommended size: 1170x290px', 'staffPlugin') ?></p>
		<input type="text" value="<?php echo esc_html($pm_staff_image_meta); ?>" name="pm_staff_image_meta" id="img-uploader-field" class="pm-admin-upload-field" />
		<input id="upload_image_button" type="button" value="<?php esc_attr_e('Media Library Image', 'staffPlugin'); ?>" class="button-secondary" />
        <div class="pm-admin-upload-staff-preview"></div>
        
        <?php if($pm_staff_image_meta) : ?>
        	<input id="remove_staff_image_button" type="button" value="<?php esc_attr_e('Remove Image', 'staffPlugin'); ?>" class="button-secondary" />
        <?php endif; ?> 
    
    <?php
	
	
	
}

function pm_staff_title_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_title_meta = get_post_meta( $post->ID, 'pm_staff_title_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_staff_title_meta); ?>" name="pm_staff_title_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_staff_quote_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_quote_meta = get_post_meta( $post->ID, 'pm_staff_quote_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_staff_quote_meta); ?>" name="pm_staff_quote_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_twitter_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_twitter_meta = get_post_meta( $post->ID, 'pm_staff_twitter_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_twitter_meta); ?>" name="pm_staff_twitter_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_facebook_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_facebook_meta = get_post_meta( $post->ID, 'pm_staff_facebook_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_facebook_meta); ?>" name="pm_staff_facebook_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_gplus_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_gplus_meta = get_post_meta( $post->ID, 'pm_staff_gplus_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_gplus_meta); ?>" name="pm_staff_gplus_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_linkedin_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_linkedin_meta = get_post_meta( $post->ID, 'pm_staff_linkedin_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_linkedin_meta); ?>" name="pm_staff_linkedin_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_email_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_email_address_meta = get_post_meta( $post->ID, 'pm_staff_email_address_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_staff_email_address_meta); ?>" name="pm_staff_email_address_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_disable_share_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_disable_share_feature = get_post_meta( $post->ID, 'pm_disable_share_feature', true );
	
	?>
        <select id="pm_disable_share_feature" name="pm_disable_share_feature" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_disable_share_feature, 'no' ); ?>><?php esc_attr_e('No', 'staffPlugin') ?></option>
            <option value="yes" <?php selected( $pm_disable_share_feature, 'yes' ); ?>><?php esc_attr_e('Yes', 'staffPlugin') ?></option>
        </select>
            
    <?php
	
}


function pm_ln_add_staff_member_fields( $staff_member_id, $post_staff ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_staff->post_type == 'post_staff' ) {
			
			// Store data in post meta table if present in post data			
			if( isset($_POST['pm_staff_image_meta'])){
				update_post_meta($staff_member_id, "pm_staff_image_meta", $_POST['pm_staff_image_meta']);
			}
			
			if(isset($_POST['pm_staff_title_meta'])){
				update_post_meta($staff_member_id, "pm_staff_title_meta", $_POST['pm_staff_title_meta']);
			}
			
			if(isset($_POST['pm_staff_quote_meta'])){
				update_post_meta($staff_member_id, "pm_staff_quote_meta", $_POST['pm_staff_quote_meta']);
			}
			
			if(isset($_POST['pm_staff_twitter_meta'])){
				update_post_meta($staff_member_id, "pm_staff_twitter_meta", $_POST['pm_staff_twitter_meta']);
			}
			
			if(isset($_POST['pm_staff_facebook_meta'])){
				update_post_meta($staff_member_id, "pm_staff_facebook_meta", $_POST['pm_staff_facebook_meta']);
			}
			
			if(isset($_POST['pm_staff_gplus_meta'])){
				update_post_meta($staff_member_id, "pm_staff_gplus_meta", $_POST['pm_staff_gplus_meta']);
			}
			
			if(isset($_POST['pm_staff_linkedin_meta'])){
				update_post_meta($staff_member_id, "pm_staff_linkedin_meta", $_POST['pm_staff_linkedin_meta']);
			}
			
			if(isset($_POST['pm_staff_email_address_meta'])){
				update_post_meta($staff_member_id, "pm_staff_email_address_meta", $_POST['pm_staff_email_address_meta']);
			}
			
			if(isset($_POST['pm_disable_share_feature'])){
				update_post_meta($staff_member_id, "pm_disable_share_feature", $_POST['pm_disable_share_feature']);
			}
				
		}
	
	endif;	
}

?>
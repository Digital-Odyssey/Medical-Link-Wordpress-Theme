<?php 

/*
Plugin Name: Services Post Type for Medical-Link Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type displaying services.
Version: 1.3
Author: Micro Themes
Author URI: http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'pm_ln_create_services_post');
add_action('init', 'pm_ln_services_cats');
add_action('admin_init', 'pm_ln_services_admin');
add_action('save_post', 'pm_ln_add_services_fields', 10, 2);
add_action('admin_menu', 'pm_ln_add_services_settings' );// ADD SETTINGS PAGE


//Translation support
add_action('plugins_loaded', 'pm_ln_load_services_textdomain');

function pm_ln_load_services_textdomain() { 
	load_plugin_textdomain( 'servicesPlugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function pm_ln_create_services_post() {
	
	$pm_services_slug = get_option('pm_services_slug');
	$slug = '';
	
	if( $pm_services_slug !== '' ) {
		$slug = $pm_services_slug;
	} else {
		$slug = 'medical-service';
	}
	
	register_post_type('post_services',
		array(
			'labels' => array(
				'name' => esc_attr__( 'Services', 'servicesPlugin' ),
				'singular_name' => esc_attr__( 'Services', 'servicesPlugin' ),
				'add_new' => esc_attr__( 'Add New Service', 'servicesPlugin' ),
				'add_new_item' => esc_attr__( 'Add New Service', 'servicesPlugin' ),
				'edit' => esc_attr__( 'Edit', 'servicesPlugin' ),
				'edit_item' => esc_attr__( 'Edit Service post', 'servicesPlugin' ),
				'new_item' => esc_attr__( 'New Service post', 'servicesPlugin' ),
				'view' => esc_attr__( 'View', 'servicesPlugin' ),
				'view_item' => esc_attr__( 'View Service post', 'servicesPlugin' ),
				'search_items' => esc_attr__( 'Search Service posts', 'servicesPlugin' ),
				'not_found' => esc_attr__( 'No Service posts found', 'servicesPlugin' ),
				'not_found_in_trash' => esc_attr__( 'No Service posts found in Trash', 'servicesPlugin' ),
				'parent' => esc_attr__( 'Parent Staff', 'servicesPlugin' )
			),
			'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => esc_attr__( 'Easily lets you add new services.', 'servicesPlugin' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array( 'slug' => $slug ),
			//'taxonomies' => array('category', 'post_tag')
		)
	);
		
}


function pm_ln_services_cats() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => esc_attr__( 'Categories', 'servicesPlugin' ),
		'singular_name' => esc_attr__( 'Categories', 'servicesPlugin' ),
		'search_items' =>  esc_attr__( 'Search Categories', 'servicesPlugin' ),
		'popular_items' => esc_attr__( 'Popular Categories', 'servicesPlugin' ),
		'all_items' => esc_attr__( 'All Categories', 'servicesPlugin' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => esc_attr__( 'Edit Category', 'servicesPlugin' ),
		'update_item' => esc_attr__( 'Update Category', 'servicesPlugin' ),
		'add_new_item' => esc_attr__( 'Add Category', 'servicesPlugin' ),
		'new_item_name' => esc_attr__( 'New Category', 'servicesPlugin' ),
		'separate_items_with_commas' => esc_attr__( 'Separate Category Titles with commas', 'servicesPlugin' ),
		'add_or_remove_items' => esc_attr__( 'Add or remove Category', 'servicesPlugin' ),
		'choose_from_most_used' => esc_attr__( 'Choose from the most used Category entries', 'servicesPlugin' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'services_cats', 'post_services', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'service-category' ), // changes name in permalink structure
    ));
	
	//flush_rewrite_rules();	
}


function pm_ln_services_admin() {
		
	//Disable Share options
	add_meta_box( 
		'pm_disable_share_feature', //ID
		'Disable Share feature?',  //label
		'pm_disable_services_share_feature_function' , //function
		'post_services', //Post type
		'side'
	);
	
	//Gallery image
	add_meta_box( 
		'pm_services_image_meta', //ID
		'Featured Image',  //label
		'pm_services_image_meta_function' , //function
		'post_services', //Post type
		'normal', 
		'high' 
	);

	
}

//Add sub menus
function pm_ln_add_services_settings() {

	//create custom top-level menu
	//add_menu_page( 'Pulsar Framework Documentation', 'Theme Documentation', 'manage_options', __FILE__, 'pm_documentation_main_page',	plugins_url( '/images/wp-icon.png', __FILE__ ) );
	
	//create sub-menu items
	add_submenu_page( 'edit.php?post_type=post_services', esc_attr__('Services Settings', 'servicesPlugin'),  esc_attr__('Services Settings', 'servicesPlugin'), 'manage_options', 'services_settings',  'pm_ln_services_settings_page' );
	
	//create an options page under Settings tab
	//add_options_page('My API Plugin', 'My API Plugin', 'manage_options', 'pm_myplugin', 'pm_myplugin_option_page');	
}


//Settings page
function pm_ln_services_settings_page() {
		
	//Save data first
	if (isset($_POST['pm_services_settings_update'])) {
		
		update_option('pm_services_slug', (string)$_POST["pm_services_slug"]);
		
		echo '<div id="message" class="updated fade"><h4>'.esc_attr__('Your settings have been saved.', 'servicesPlugin').'</h4></div>';
		
	}//end of save data
	
	$pm_services_slug = get_option('pm_services_slug');

	
	?>
	
	<div class="wrap">
		<?php screen_icon(); ?>
		<h2><?php esc_attr_e('Services Settings', 'servicesPlugin') ?></h2>
		
		<h4><?php esc_attr_e('Configure the settings for the Services plug-in below:', 'servicesPlugin') ?></h4>
		
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		
			<input type="hidden" name="pm_services_settings_update" id="pm_services_settings_update" value="true" />
								
			<label for="pm_services_slug"><?php esc_attr_e('Slug name', 'servicesPlugin') ?></label>
			<input type="text" id="pm_services_slug" name="pm_services_slug" value="<?php echo $pm_services_slug; ?>">
			
            <p><?php esc_attr_e('<strong>NOTE:</strong> You will have to reset your permalinks after making changes to the slug name in order to avoid 404 error pages.', 'servicesPlugin') ?></p>
            
			<br /><br />
            
			<div class="pm-payel-submit">
				<input type="submit" name="pm_settings_update" class="button button-primary button-large" value="<?php esc_attr_e('Update Settings', 'servicesPlugin'); ?> &raquo;" />
			</div>
		
		</form>
		
	</div>
	
	<?php
	
}


function pm_services_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_services_image_meta = get_post_meta( $post->ID, 'pm_services_image_meta', true );
		

	//HTML code
	?>
    	<p><?php esc_attr_e('Recommended size: 1170x400px','servicesPlugin'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_services_image_meta); ?>" name="pm_services_image_meta" id="featured-img-uploader-field" class="pm-admin-upload-field featured-img-uploader-field" />
		<input id="featured_upload_image_button" type="button" value="<?php esc_attr_e('Media Library Image', 'servicesPlugin'); ?>" class="button-secondary" />
        <div class="pm-admin-gallery-image-preview"></div>
        
        <?php if($pm_services_image_meta) : ?>
        	<input id="remove_gallery_image_button" type="button" value="<?php esc_attr_e('Remove Image', 'servicesPlugin'); ?>" class="button-secondary" />
        <?php endif; ?>
        
    
    <?php
	
}

function pm_disable_services_share_feature_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_disable_share_feature = get_post_meta( $post->ID, 'pm_disable_share_feature', true );
	
	?>
        <select id="pm_disable_share_feature" name="pm_disable_share_feature" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_disable_share_feature, 'no' ); ?>><?php esc_attr_e('No', 'servicesPlugin') ?></option>
            <option value="yes" <?php selected( $pm_disable_share_feature, 'yes' ); ?>><?php esc_attr_e('Yes', 'servicesPlugin') ?></option>
        </select>
            
    <?php
	
}


function pm_ln_add_services_fields( $post_id, $post_services ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_services->post_type == 'post_services' ) {
			
			// Store data in post meta table if present in post data				
			if(isset($_POST['pm_disable_share_feature'])){
				update_post_meta($post_id, "pm_disable_share_feature", $_POST['pm_disable_share_feature']);
			}
			
			if(isset($_POST['pm_services_image_meta'])){
				update_post_meta($post_id, "pm_services_image_meta", $_POST['pm_services_image_meta']);
			}
				
		}
	
	endif;	
}

?>
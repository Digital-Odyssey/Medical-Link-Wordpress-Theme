<?php 

/*
Plugin Name: Medical Locations
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type for creating a list of medical locations.
Version: 1.0
Author: Micro Themes
Author URI:http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'pm_ln_create_locations');
add_action('init', 'pm_ln_create_locations_countries');
add_action('admin_init', 'pm_ln_location_metaboxes');
add_action('save_post', 'pm_ln_save_location_fields', 10, 2);
add_action('admin_menu', 'pm_ln_add_location_settings' );// ADD SETTINGS PAGE

//Translation support
add_action('plugins_loaded', 'pm_ln_load_locations_textdomain');

function pm_ln_load_locations_textdomain() { 
	load_plugin_textdomain( 'locationPlugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function pm_ln_create_locations() {
	
	$pm_ln_locations_slug = get_option('pm_ln_locations_slug');
	$slug = '';
	
	if( $pm_ln_locations_slug !== '' ) {
		$slug = $pm_ln_locations_slug;
	} else {
		$slug = 'medical-locations';
	}
	
    register_post_type( 'post_locations',
        array(
            'labels' => array(
				'name' => esc_attr__( 'Locations', 'locationPlugin' ),
				'singular_name' => esc_attr__( 'Location', 'locationPlugin' ),
				'add_new' => esc_attr__( 'Add New Location', 'locationPlugin' ),
				'add_new_item' => esc_attr__( 'Add New Location', 'locationPlugin' ),
				'edit' => esc_attr__( 'Edit', 'locationPlugin' ),
				'edit_item' => esc_attr__( 'Edit Location', 'locationPlugin' ),
				'new_item' => esc_attr__( 'New Location', 'locationPlugin' ),
				'view' => esc_attr__( 'View', 'locationPlugin' ),
				'view_item' => esc_attr__( 'View Location', 'locationPlugin' ),
				'search_items' => esc_attr__( 'Search Locations', 'locationPlugin' ),
				'not_found' => esc_attr__( 'No Locations found', 'locationPlugin' ),
				'not_found_in_trash' => esc_attr__( 'No Locations found in Trash', 'locationPlugin' ),
				'parent' => esc_attr__( 'Parent Location', 'locationPlugin' )
			),
            'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt', 'thumbnail'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => esc_attr__( 'Easily lets you add new medical locations', 'locationPlugin' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => $slug),
			//'taxonomies' => array('category', 'post_tag')
			
        )
    );
	
}

function pm_ln_create_locations_countries() {
	
	$pm_ln_countries_slug = get_option('pm_ln_countries_slug');
	$slug = '';
	
	if( $pm_ln_countries_slug !== '' ) {
		$slug = $pm_ln_countries_slug;
	} else {
		$slug = 'countries';
	}
	
	// create the array for 'labels'
    $labels = array(
		'name' => esc_attr__( 'Countries', 'locationPlugin' ),
		'singular_name' => esc_attr__( 'Countries', 'locationPlugin' ),
		'search_items' =>  esc_attr__( 'Search Countries', 'locationPlugin' ),
		'popular_items' => esc_attr__( 'Popular Countries', 'locationPlugin' ),
		'all_items' => esc_attr__( 'All Countries', 'locationPlugin' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => esc_attr__( 'Edit Country', 'locationPlugin' ),
		'update_item' => esc_attr__( 'Update Country', 'locationPlugin' ),
		'add_new_item' => esc_attr__( 'Add Country', 'locationPlugin' ),
		'new_item_name' => esc_attr__( 'New Country', 'locationPlugin' ),
		'separate_items_with_commas' => esc_attr__( 'Separate Countries with commas', 'locationPlugin' ),
		'add_or_remove_items' => esc_attr__( 'Add or remove Country', 'locationPlugin' ),
		'choose_from_most_used' => esc_attr__( 'Choose from the most used Countries', 'locationPlugin' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'locations_countries', 'post_locations', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'countries' ), // changes name in permalink structure
    ));
	
	flush_rewrite_rules();	
}

//Add sub menus
function pm_ln_add_location_settings() {

	//create custom top-level menu
	//add_menu_page( 'Pulsar Framework Documentation', 'Theme Documentation', 'manage_options', __FILE__, 'pm_documentation_main_page',	plugins_url( '/images/wp-icon.png', __FILE__ ) );
	
	//create sub-menu items
	add_submenu_page( 'edit.php?post_type=post_locations', esc_attr__('Location Settings', 'locationPlugin'),  esc_attr__('Location Settings', 'locationPlugin'), 'manage_options', 'locations_settings',  'pm_ln_locations_settings_page' );
	
	//create an options page under Settings tab
	//add_options_page('My API Plugin', 'My API Plugin', 'manage_options', 'pm_myplugin', 'pm_myplugin_option_page');	
}


//Settings page
function pm_ln_locations_settings_page() {
		
	//Save data first
	if (isset($_POST['pm_ln_location_settings_update'])) {
		
		update_option('pm_ln_locations_slug', (string)$_POST["pm_ln_locations_slug"]);
		update_option('pm_ln_countries_slug', (string)$_POST["pm_ln_countries_slug"]);
		update_option('pm_ln_activate_country_list', (string)$_POST["pm_ln_activate_country_list"]);
			
		
		echo '<div id="message" class="updated fade"><h4>'.esc_attr__('Your settings have been saved.', 'locationPlugin').'</h4></div>';
		
	}//end of save data
	
	$pm_ln_locations_slug = get_option('pm_ln_locations_slug');
	$pm_ln_countries_slug = get_option('pm_ln_countries_slug');
	$pm_ln_activate_country_list = get_option('pm_ln_activate_country_list');
	
	
	?>
	
	<div class="wrap">
		<?php screen_icon(); ?>
		<h2><?php esc_attr_e('Locations settings', 'locationPlugin') ?></h2>
		
		<h4><?php esc_attr_e('Configure the settings for the Locations plug-in below:', 'locationPlugin') ?></h4>
		
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		
			<input type="hidden" name="pm_ln_location_settings_update" id="pm_ln_location_settings_update" value="true" />
								
			<label for="pm_ln_locations_slug"><?php esc_attr_e('Property slug name', 'locationPlugin') ?></label>
			<input type="text" id="pm_ln_locations_slug" name="pm_ln_locations_slug" value="<?php echo esc_attr($pm_ln_locations_slug); ?>">
			
            <p><b><?php esc_attr_e('NOTE:', 'locationPlugin') ?></b> <?php esc_attr_e('You will have to reset your permalinks after making changes to the slug name in order to avoid 404 error pages.', 'locationPlugin') ?></p>
            
            <label for="pm_ln_countries_slug"><?php esc_attr_e('Country taxonomy slug name', 'locationPlugin') ?></label>
			<input type="text" id="pm_ln_countries_slug" name="pm_ln_countries_slug" value="<?php echo esc_attr($pm_ln_countries_slug); ?>">
            
            <br /><br />
            
            <label for="pm_ln_activate_country_list"><?php esc_attr_e('Display countries and locations in appointment form?', 'locationPlugin') ?></label>
			<select name="pm_ln_activate_country_list">
            	<option value="yes" <?php selected($pm_ln_activate_country_list, 'yes') ?>><?php esc_attr_e('YES', 'locationPlugin'); ?></option>
                <option value="no" <?php selected($pm_ln_activate_country_list, 'no') ?>><?php esc_attr_e('NO', 'locationPlugin'); ?></option>
            </select>
            
                                    
            <br /><br />
            
            
            
			<div class="pm-payel-submit">
				<input type="submit" name="pm_settings_update" class="button button-primary button-large" value="<?php esc_attr_e('Update Settings', 'locationPlugin'); ?> &raquo;" />
			</div>
		
		</form>
		
	</div>
	
	<?php
	
}

function pm_ln_location_metaboxes() {
	
    //Header Image
	add_meta_box( 
		'pm_location_header_image_meta', //ID
		esc_attr__('Header Image', 'locationPlugin'),  //label
		'pm_location_header_image_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	
	//Address title
	add_meta_box( 
		'pm_ln_location_address_title_meta', //ID
		esc_attr__('Address title', 'locationPlugin'),  //label
		'pm_ln_location_address_title_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Address
	add_meta_box( 
		'pm_ln_location_address_meta', //ID
		esc_attr__('Address', 'locationPlugin'),  //label
		'pm_ln_location_address_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//City
	add_meta_box( 
		'pm_ln_location_city_meta', //ID
		esc_attr__('City', 'locationPlugin'),  //label
		'pm_ln_location_city_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Province
	add_meta_box( 
		'pm_ln_location_province_meta', //ID
		esc_attr__('State/Province', 'locationPlugin'),  //label
		'pm_ln_location_province_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Zip/Postal
	add_meta_box( 
		'pm_ln_location_zip_meta', //ID
		esc_attr__('Zip/Postal Code', 'locationPlugin'),  //label
		'pm_ln_location_zip_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
		
	//Social title
	add_meta_box( 
		'pm_ln_location_social_title_meta', //ID
		esc_attr__('Social title', 'locationPlugin'),  //label
		'pm_ln_location_social_title_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
			
	//Twitter Address
	add_meta_box( 
		'pm_ln_location_twitter_meta', //ID
		esc_attr__('Twitter Address', 'locationPlugin'),  //label
		'pm_ln_location_twitter_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Facebook Address
	add_meta_box( 
		'pm_ln_location_facebook_meta', //ID
		esc_attr__('Facebook Address', 'locationPlugin'),  //label
		'pm_ln_location_facebook_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Google Plus Address
	add_meta_box( 
		'pm_ln_location_gplus_meta', //ID
		esc_attr__('Google Plus Address', 'locationPlugin'),  //label
		'pm_ln_location_gplus_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Linkedin Address
	add_meta_box( 
		'pm_ln_location_linkedin_meta', //ID
		esc_attr__('Linkedin Address', 'locationPlugin'),  //label
		'pm_ln_location_linkedin_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Email Address
	add_meta_box( 
		'pm_ln_location_email_address_meta', //ID
		esc_attr__('Email Address', 'locationPlugin'),  //label
		'pm_ln_location_email_address_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Google map
	add_meta_box( 
		'pm_ln_location_gmap_meta', //ID
		esc_attr__('Google Map', 'locationPlugin'),  //label
		'pm_ln_location_gmap_meta_function' , //function
		'post_locations', //Post type
		'normal', 
		'high' 
	);
	
	//Disable Share options
	add_meta_box( 
		'pm_ln_location_disable_share', //ID
		esc_attr__('Disable Share feature?', 'locationPlugin'),  //label
		'pm_ln_location_disable_share_function' , //function
		'post_locations', //Post type
		'side'
	);
	
}


function pm_location_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_location_header_image_meta = get_post_meta( $post->ID, 'pm_header_image_meta', true );
		

	//HTML code
	?>
    	<p><?php esc_attr_e('Recommended size: 1170x290px', 'locationPlugin') ?></p>
		<input type="text" value="<?php echo esc_html($pm_location_header_image_meta); ?>" name="pm_header_image_meta" id="img-uploader-field" class="pm-admin-upload-field" />
		<input id="upload_image_button" type="button" value="<?php esc_attr_e('Media Library Image', 'locationPlugin'); ?>" class="button-primary" />
        <div class="pm-admin-upload-staff-preview"></div>
        
        <?php if($pm_location_header_image_meta) : ?>
        	<input id="remove_staff_image_button" type="button" value="<?php esc_attr_e('Remove Image', 'locationPlugin'); ?>" class="button-secondary" />
        <?php endif; ?> 
    
    <?php
	
}



function pm_ln_location_social_title_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value
	$pm_ln_location_social_title_meta = get_post_meta( $post->ID, 'pm_ln_location_social_title_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_ln_location_social_title_meta); ?>" name="pm_ln_location_social_title_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_ln_location_address_title_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value
	$pm_ln_location_address_title_meta = get_post_meta( $post->ID, 'pm_ln_location_address_title_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_ln_location_address_title_meta); ?>" name="pm_ln_location_address_title_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_ln_location_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value
	$pm_ln_location_address_meta = get_post_meta( $post->ID, 'pm_ln_location_address_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_ln_location_address_meta); ?>" name="pm_ln_location_address_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_ln_location_city_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_city_meta = get_post_meta( $post->ID, 'pm_ln_location_city_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_ln_location_city_meta); ?>" name="pm_ln_location_city_meta" class="pm-admin-text-field" />
    
    <?php
	
}



function pm_ln_location_province_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_province_meta = get_post_meta( $post->ID, 'pm_ln_location_province_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_ln_location_province_meta); ?>" name="pm_ln_location_province_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_ln_location_zip_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_zip_meta = get_post_meta( $post->ID, 'pm_ln_location_zip_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_ln_location_zip_meta); ?>" name="pm_ln_location_zip_meta" class="pm-admin-text-field" />
    
    <?php
	
}



function pm_ln_location_twitter_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_twitter_meta = get_post_meta( $post->ID, 'pm_ln_location_twitter_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_ln_location_twitter_meta); ?>" name="pm_ln_location_twitter_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_ln_location_facebook_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_facebook_meta = get_post_meta( $post->ID, 'pm_ln_location_facebook_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_ln_location_facebook_meta); ?>" name="pm_ln_location_facebook_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_ln_location_gplus_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_gplus_meta = get_post_meta( $post->ID, 'pm_ln_location_gplus_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_ln_location_gplus_meta); ?>" name="pm_ln_location_gplus_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_ln_location_linkedin_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_linkedin_meta = get_post_meta( $post->ID, 'pm_ln_location_linkedin_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_ln_location_linkedin_meta); ?>" name="pm_ln_location_linkedin_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_ln_location_email_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_email_address_meta = get_post_meta( $post->ID, 'pm_ln_location_email_address_meta', true );
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_ln_location_email_address_meta); ?>" name="pm_ln_location_email_address_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_ln_location_gmap_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_ln_location_gmap_lat_meta = get_post_meta( $post->ID, 'pm_ln_location_gmap_lat_meta', true );
	$pm_ln_location_gmap_long_meta = get_post_meta( $post->ID, 'pm_ln_location_gmap_long_meta', true );
	$pm_ln_location_gmap_message_meta = get_post_meta( $post->ID, 'pm_ln_location_gmap_message_meta', true );
	$pm_ln_location_gmap_height_meta = get_post_meta( $post->ID, 'pm_ln_location_gmap_height_meta', true );
		

	//HTML code
	?>
    
    	<label for="pm_ln_location_gmap_lat_meta"><?php esc_attr_e('Lattitude', 'locationPlugin') ?></label>
		<input type="text" value="<?php echo esc_attr($pm_ln_location_gmap_lat_meta); ?>" name="pm_ln_location_gmap_lat_meta" class="pm-admin-text-field" />
        
        <label for="pm_ln_location_gmap_long_meta"><?php esc_attr_e('Longitude', 'locationPlugin') ?></label>
		<input type="text" value="<?php echo esc_attr($pm_ln_location_gmap_long_meta); ?>" name="pm_ln_location_gmap_long_meta" class="pm-admin-text-field" />
        
        <label for="pm_ln_location_gmap_message_meta"><?php esc_attr_e('Message', 'locationPlugin') ?></label>
		<textarea name="pm_ln_location_gmap_message_meta" class="pm-admin-text-field" /><?php echo esc_attr($pm_ln_location_gmap_message_meta); ?></textarea>
        
        <label for="pm_ln_location_gmap_height_meta"><?php esc_attr_e('Height', 'locationPlugin') ?></label>
		<input type="text" value="<?php echo esc_attr($pm_ln_location_gmap_height_meta); ?>" name="pm_ln_location_gmap_height_meta" class="pm-admin-text-field" />
    
    <?php
	
}



function pm_ln_location_disable_share_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( 'theme_metabox', 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_ln_location_disable_share = get_post_meta( $post->ID, 'pm_ln_location_disable_share', true );
	
	?>
        <select id="pm_ln_location_disable_share" name="pm_ln_location_disable_share" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_ln_location_disable_share, 'no' ); ?>><?php esc_attr_e('No', 'locationPlugin') ?></option>
            <option value="yes" <?php selected( $pm_ln_location_disable_share, 'yes' ); ?>><?php esc_attr_e('Yes', 'locationPlugin') ?></option>
        </select>
            
    <?php
	
}


function pm_ln_save_location_fields( $post_id, $post_type ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_type->post_type == 'post_locations' ) {
			
			// Store data in post meta table if present in post data			
			if( isset($_POST['pm_header_image_meta'])){
				update_post_meta($post_id, "pm_header_image_meta", $_POST['pm_header_image_meta']);
			}
			
			if(isset($_POST['pm_ln_location_social_title_meta'])){
				update_post_meta($post_id, "pm_ln_location_social_title_meta", sanitize_text_field($_POST['pm_ln_location_social_title_meta']));
			}
			
			if(isset($_POST['pm_ln_location_address_title_meta'])){
				update_post_meta($post_id, "pm_ln_location_address_title_meta", sanitize_text_field($_POST['pm_ln_location_address_title_meta']));
			}
			
			if(isset($_POST['pm_ln_location_address_meta'])){
				update_post_meta($post_id, "pm_ln_location_address_meta", sanitize_text_field($_POST['pm_ln_location_address_meta']));
			}
			
			if(isset($_POST['pm_ln_location_city_meta'])){
				update_post_meta($post_id, "pm_ln_location_city_meta", sanitize_text_field($_POST['pm_ln_location_city_meta']));
			}
			
			if(isset($_POST['pm_ln_location_province_meta'])){
				update_post_meta($post_id, "pm_ln_location_province_meta", sanitize_text_field($_POST['pm_ln_location_province_meta']));
			}
			
			if(isset($_POST['pm_ln_location_zip_meta'])){
				update_post_meta($post_id, "pm_ln_location_zip_meta", sanitize_text_field($_POST['pm_ln_location_zip_meta']));
			}
			
			if(isset($_POST['pm_ln_location_twitter_meta'])){
				update_post_meta($post_id, "pm_ln_location_twitter_meta", sanitize_text_field($_POST['pm_ln_location_twitter_meta']));
			}
			
			if(isset($_POST['pm_ln_location_facebook_meta'])){
				update_post_meta($post_id, "pm_ln_location_facebook_meta", sanitize_text_field($_POST['pm_ln_location_facebook_meta']));
			}
			
			if(isset($_POST['pm_ln_location_gplus_meta'])){
				update_post_meta($post_id, "pm_ln_location_gplus_meta", sanitize_text_field($_POST['pm_ln_location_gplus_meta']));
			}
			
			if(isset($_POST['pm_ln_location_linkedin_meta'])){
				update_post_meta($post_id, "pm_ln_location_linkedin_meta", sanitize_text_field($_POST['pm_ln_location_linkedin_meta']));
			}
			
			if(isset($_POST['pm_ln_location_email_address_meta'])){
				update_post_meta($post_id, "pm_ln_location_email_address_meta", sanitize_text_field($_POST['pm_ln_location_email_address_meta']));
			}
			
			
			
			if(isset($_POST['pm_ln_location_gmap_lat_meta'])){
				update_post_meta($post_id, "pm_ln_location_gmap_lat_meta", sanitize_text_field($_POST['pm_ln_location_gmap_lat_meta']));
			}
			
			if(isset($_POST['pm_ln_location_gmap_long_meta'])){
				update_post_meta($post_id, "pm_ln_location_gmap_long_meta", sanitize_text_field($_POST['pm_ln_location_gmap_long_meta']));
			}
			
			if(isset($_POST['pm_ln_location_gmap_message_meta'])){
				update_post_meta($post_id, "pm_ln_location_gmap_message_meta", sanitize_text_field($_POST['pm_ln_location_gmap_message_meta']));
			}
			
			if(isset($_POST['pm_ln_location_gmap_height_meta'])){
				update_post_meta($post_id, "pm_ln_location_gmap_height_meta", sanitize_text_field($_POST['pm_ln_location_gmap_height_meta']));
			}
			
			
			
			
			if(isset($_POST['pm_ln_location_disable_share'])){
				update_post_meta($post_id, "pm_ln_location_disable_share", sanitize_text_field($_POST['pm_ln_location_disable_share']));
			}
				
		}
	
	endif;	
}

?>